// script.js

// Countdown Timer
const countdownElement = document.getElementById('countdown');
let countdown = 10 * 60; // 10 minutes

function updateCountdown() {
    const minutes = Math.floor(countdown / 60);
    const seconds = countdown % 60;
    countdownElement.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    countdown--;

    if (countdown < 0) {
        clearInterval(countdownInterval);
        countdownElement.textContent = 'Expired';
    }
}

updateCountdown();
const countdownInterval = setInterval(updateCountdown, 1000);

// Slide-Up Form
setTimeout(() => {
    document.getElementById('slide-up-form').style.bottom = '20px';
}, 15000);
