<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $recipeName = $_POST['recipe_name'];
    $ingredients = $_POST['ingredients'];
    $instructions = $_POST['instructions'];

    
    echo "<h2 class='mt-4'>Submitted Recipe</h2>";
    echo "<p><strong>Recipe Name:</strong> $recipeName</p>";
    echo "<p><strong>Ingredients:</strong> $ingredients</p>";
    echo "<p><strong>Instructions:</strong> $instructions</p>";
}
?>


<form method="post" action="">
    <h2 class="mt-4">Submit a Recipe</h2>

    <div class="form-group">
        <label for="recipe_name">Recipe Name:</label>
        <input type="text" class="form-control" id="recipe_name" name="recipe_name" required>
    </div>

    <div class="form-group">
        <label for="ingredients">Ingredients:</label>
        <textarea class="form-control" id="ingredients" name="ingredients" rows="3" required></textarea>
    </div>

    <div class="form-group">
        <label for="instructions">Instructions:</label>
        <textarea class="form-control" id="instructions" name="instructions" rows="3" required></textarea>
    </div>

    <button type="submit" class="btn btn-primary">Submit Recipe</button>
</form>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <title>Recipe Blog</title>
</head>
<body>

    <div class="container">
        <h1 class="mt-5 mb-4">Recipe Blog</h1>

       
        <div id="recipe-list">
            
        </div>

        
        <div id="submission-form" class="mt-5">
            <?php include 'submission_form.php'; ?>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
/* Add your custom styles here */
body {
    background-color: #f8f9fa;
}

.container {
    max-width: 800px;
}

#recipe-list {
    /* Add styles for recipe list */
}

#submission-form {
    /* Add styles for submission form */
}

