document.addEventListener("DOMContentLoaded", function() {
    setTimeout(function() {
        document.getElementById("formContainer").style.display = "block";
    }, 15000); // Show form after 15 seconds
});
